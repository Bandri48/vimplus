package kg.ash.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.math.BigDecimal;

public class LambdaNamedClass {

    public LambdaNamedClass() {
        List<? super Integer[]> lint = new ArrayList<>();
        List<List<HashMap<String,BigDecimal>>> list 
            = new ArrayList<>();

        lint.stream().filter((String t, BigDecimal d) -> {
            Integer i = new Integer();
            t.
            d.
        });

    }
    
}
