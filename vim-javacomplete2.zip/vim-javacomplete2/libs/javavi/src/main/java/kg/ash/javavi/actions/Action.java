package kg.ash.javavi.actions;

public interface Action {
    String perform(String[] args);
}
