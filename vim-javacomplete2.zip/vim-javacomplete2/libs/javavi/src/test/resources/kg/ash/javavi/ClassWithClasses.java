package kg.ash.javavi;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ClassWithClasses extends LinkedList {

    List list = new ArrayList<String>();

    public String method() {
        BigDecimal bd = BigDecimal.ONE;
        return "return";
    }
}
